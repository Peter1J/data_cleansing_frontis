Exact Hash
==========

.. automodule:: text_dedup.exact_hash
   :members:
   :undoc-members:
   :noindex:
