Line-level Exact Hash
=====================

.. automodule:: text_dedup.ccnet
   :members:
   :undoc-members:
   :noindex:
