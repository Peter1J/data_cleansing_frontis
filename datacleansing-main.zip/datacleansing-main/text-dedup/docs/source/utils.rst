Utility Functions and Classes
=============================
.. automodule:: text_dedup.utils
   :members:
   :undoc-members:
   :noindex: