#!/bin/bash

#SBATCH --job-name=langchao
#SBATCH --partition=LLM
#SBATCH  -N 1
#SBATCH --ntasks-per-node 64
#SBATCH -w gnode02
#SBATCH --output=./logs/%j.out
#SBATCH --error=./logs/%j.err

ulimit -n

dataset="jdItem"
clearning_version="v1"
source_dir="/hpc_data/data_warehouse/SourceData/JDItem_pattern_dataset/SampledRawDataset/"
dest_dir="/hpc_data/data_warehouse/CleanData/cn-jd-product/${clearning_version}"

echo ${dest_dir}

# Step1: Perform dataset cleaning
python clean.py \
    --num_workers 32 \
    --dataset_name ${dataset} \
    --source_path ${source_dir} \
    --dest_path ${dest_dir}
if [ $? -ne 0 ]; then
    echo "clean.py failed."
    exit
else
    echo "clean.py succeed."

# Step2: Make tokenizing with Frontis-LLaMA-13B, to yield ${dataset}-meta-info.json
tokenizer_path=""
python tokenizer.py \
    --dataset_name ${dataset} \
    --dataset_path ${dest_dir}/good \
    --output_path ${dest_dir} \
    --tokenizer_path ${tokenizer_path} \
    --version ${clearning_version}
if [ $? -ne 0 ]; then
    echo "tokenizer.py failed."
    exit
else
    echo "tokenizer.py succeed."
fi

# Step3: Sample 100 datas for evaluation, to produce ${dataset}-sample100.jsonl
python random_sample.py \
    --dataset_name ${dataset} \
    --dataset_path ${dest_dir} \
    --output_path ${dest_dir} \
    --number_sample 100
if [ $? -ne 0 ]; then
    echo "random_sample.py failed."
    exit
else
    echo "random_sample.py succeed."
fi

