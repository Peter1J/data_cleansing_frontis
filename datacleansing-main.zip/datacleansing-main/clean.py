import os
import json
import multiprocessing as mp
import re
from tqdm import tqdm
import argparse
from os import listdir, path
from general_clean import GClean
from read_xhs_note_data import read_data, read_excel
from tqdm import tqdm
from textrank4zh import TextRank4Keyword, TextRank4Sentence
import regex as re
from summerizer import truncate_sentence, remove_initial_symbols
from jieba.analyse import extract_tags
from emoji import emojize, demojize
import multiprocessing as mp
from sensitive_words import SENSITIVE_WORDS

LONG_REQUIRED = 50
PROCESS = 120
sensitive_words = SENSITIVE_WORDS

cleaner = GClean(LONG_REQUIRED)

def val_pro(val):
    if val == 'null' or val is None:
        return 0
    else:
        return int(val)


def jobj2clean(jobj):
    """
        mp process controller
    """
    for itm in tqdm(jobj):
        yield itm


def controller(input_file):
    with open(input_file,"r",encoding="utf-8") as f:
        for line_no,line in tqdm(enumerate(f.readlines())):
            line = line.strip()
            if len(line) < 1: continue
            yield (line_no,line,input_file)

def step1(text):

    if len(cleaned_content) < 50:
        return "step1", "0", text

    # g0 CleanScript
    cleaned_content = cleaner.clean_script(text)
    # g4 CleanDuplicatedPunctuation
    cleaned_content = cleaner.clean_deplicate_punc(cleaned_content)

    # g1 InvalidWords + g22 ChineseLessThan60
    cleaned_content = cleaner.clean_valid(cleaned_content)

    # g2 CleanPunctuationsAtHeadTail
    cleaned_content = cleaner.clean_punct_at_last(cleaned_content)
    cleaned_content = cleaner.clean_punct_at_begin(cleaned_content)

    # g3 EngPeriod2ChinPeriod
    cleaned_content = re.sub('\\[.*?]', '。', cleaned_content)

    # g5 FanTi2Simplify
    cleaned_content = re.sub('「', '“', cleaned_content)
    cleaned_content = re.sub('」', '”', cleaned_content)
    cleaned_content = re.sub('【', '[', cleaned_content)
    cleaned_content = re.sub('】', ']', cleaned_content)

    # g16 CleanPersonInfoDoc
    cleaned_content = cleaner.clean_private(cleaned_content)

    # g6 CleanURL
    cleaned_content = cleaner.clean_url(cleaned_content)

    # g7 CleanContinueousPuncs
    cleaned_content = cleaner.clean_continueous_punc(cleaned_content)

    # g10 CleanDuplicationInText
    cleaned_content = cleaner.delete_2repeating_long_patterns(cleaned_content)

    # g13 TooShortSentence
    cleaned_content = cleaner.filter_long_sentences(cleaned_content)
    
    # g20 TooLongSentence
    cleaned_content = cleaner.remove_long_strings_without_punctuation(cleaned_content)
    
    # g24 LongEnough
    if len(cleaned_content) >= 50:
        return "step1", "1", cleaned_content
    return "step1", "0", cleaned_content

def step2(text):
    cleaner.remove_strings_with_keywords(text, sensitive_words)

def step3():
    pass

def make_clean(items):
    line_no,line,input_file = items

    clean_policy = ""
    clean_status = 0

    # step 1: text normalization
    clean_policy,clean_status,text = step1(line)
    if clean_status == 1:
        # step 2: low quality
        clean_policy,clean_status,text = step2(text)
        if clean_status == 1:
            # step 3: text duplication
            clean_policy,clean_status,text = step3(text)


    return {
        "id":line_no,
        "source_id":"",
        "source":"langchao_yuan1.0",
        "subset":"{}".format(os.path.basename(input_file)),
        "clean_policy":"{}".format(clean_policy if clean_status == 0 else ""),
        "clean_status":clean_status,
        "content":text,
    }

def HandleSingleFile(input_file, good_fo, bad_fo):
    pools = mp.Pool(PROCESS)

    flush_steps = 0
    flush_per_steps = 50
    for res in pools.imap(make_clean, controller(input_file)):
        jstr = json.dumps(res, ensure_ascii=False)
        if res["clean_status"] == 1:
            good_fo.write(jstr+"\n")
        else:
            bad_fo.write(jstr+"\n")
        flush_steps += 1
        if flush_steps % flush_per_steps == 0:
            good_fo.flush()
            bad_fo.flush()

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source_path',
                        type=str,
                        default="/hpc_data/pangwei/yuan1.0/open_source_1T",
                        help='Directory containing trained actor model')
    parser.add_argument('--dest_path',
                        type=str,
                        default="/hpc_data/pangwei/yuan1.0/open_source_1T",
                        help='Directory containing trained actor model')


    args = parser.parse_args()
    return args

if __name__ == '__main__':
    args = parse_args()
    files = sorted(listdir(args.data_path))

    GoodDir = os.path.join(args.dest_path, "good")
    BadDir = os.path.join(args.dest_path, "bad")

    if not os.path.exists(GoodDir):
        os.makedirs(GoodDir, exist_ok=True)
    if not os.path.exists(BadDir):
        os.makedirs(BadDir,exist_ok=True)

    for input_file in tqdm(files,total=len(files)):

        good_output_file = os.path.join(GoodDir, input_file)
        if os.path.exists(good_output_file): os.remove(good_output_file)
        good_fo = open(good_output_file, 'a+', encoding='utf-8')

        bad_output_file = os.path.join(GoodDir, input_file)
        if os.path.exists(bad_output_file): os.remove(bad_output_file)
        bad_fo = open(bad_output_file, 'a+', encoding='utf-8')

        HandleSingleFile(input_file, good_fo, bad_fo)

        good_fo.close()
        bad_fo.close()
